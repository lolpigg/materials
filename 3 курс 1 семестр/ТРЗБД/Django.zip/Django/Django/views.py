from django.shortcuts import render
from django.http import HttpResponse
from shop.models import *


def main(request):
    toys_list = Toy.objects.all()
    context = {'toys' : toys_list}
    return render(request, 'Django/home.html', context)
def api(request):
    return render(request, 'Django/api.html')
def cart(request):
    return render(request, 'Django/cart.html')
def own_cab(request):
    return render(request, 'Django/own_cab.html')
def base(request):
    return render(request, 'base.html')

