from django import forms
from .models import *
from django.contrib.auth.forms import AuthenticationForm, UserCreationForm

class EmailForm(forms.Form):
    subject = forms.CharField(label='Заголовок письма', max_length=30, strip=True, widget=forms.TextInput)
    content = forms.CharField(label='Тело письма', strip=True, widget=forms.Textarea(attrs={"class": "form-control"}))

class SupplierForm(forms.ModelForm):
    class Meta:
        model = Supplier
        fields = {"name","telephone", "address"}
        widgets={
            "name": forms.TextInput(
                attrs={
                    "class":"form-control"
                }
            ),
            "telephone": forms.TextInput(
                attrs={
                    "class": "form-control"
                }
            ),
            "address": forms.TextInput(
                attrs={
                    "class": "form-control"
                }
            )
        }

class CategoryForm(forms.ModelForm):
    class Meta:
        model = Category
        fields = {"name","description"}
        widgets={
            "name": forms.TextInput(
                attrs={
                    "class":"form-control"
                }
            ),
            "description": forms.Textarea(
                attrs={
                    "class": "form-control"
                }
            )
        }

from django import forms
from .models import Toy
class ToyForm(forms.ModelForm):
    class Meta:
        model = Toy
        fields = 'name', 'description', 'price', 'photo', 'exist', 'supplier', 'category'
        widgets = {
            'name': forms.TextInput(attrs={'class': 'form-control'}),
            'description': forms.Textarea(attrs={'class': 'form-control'}),
            'price': forms.NumberInput(attrs={'class': 'form-control'}),
            'photo': forms.ClearableFileInput(attrs={'class': 'form-control-file'}),
            'exist': forms.CheckboxInput(attrs={'class': 'form-check-input'}),
            'supplier': forms.Select(attrs={'class': 'form-control'}),
            'category': forms.Select(attrs={'class': 'form-control'}),
        }


class OrderForm(forms.ModelForm):
    class Meta:
        model = Order
        fields = '__all__'

class PosOrderToyForm(forms.ModelForm):
    class Meta:
        model = Pos_Order_Toy
        fields = ['toy', 'count_toys', 'discount']

class RegisForm(UserCreationForm):
    username = forms.CharField()
    password1 = forms.CharField()
    password2 = forms.CharField()

class LoginForm(AuthenticationForm):
    login = forms.CharField()
    password = forms.CharField()