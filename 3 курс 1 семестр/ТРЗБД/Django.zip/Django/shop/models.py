from django.db import models
from django.urls import reverse, reverse_lazy
# Create your models here.
class Toy(models.Model):
    name = models.CharField(max_length=50, verbose_name="Название")
    description = models.TextField()
    price = models.IntegerField()
    photo = models.ImageField(upload_to='image/%Y/%m/%d/', blank=True)
    date_create = models.DateField(auto_now_add=True)
    date_update = models.DateField(auto_now=True)
    exist = models.BooleanField(default=True)
    supplier = models.ForeignKey('Supplier', on_delete=models.PROTECT, null=True)
    category = models.ForeignKey('Category', on_delete=models.PROTECT, null=True)
    # MtM = models.ManyToManyField('Supplier', )
    # MtM_with_table = models.ManyToManyField('Supplier', through='cheque_toy')

    def __str__(self):
        return f'{self.name} - {self.price}'
    class Meta():
        verbose_name="Игрушка"
        verbose_name_plural="Игрушки"
        ordering = ['name', '-price']
    def get_absolute_url(self):
        return reverse_lazy("view_toys")

class Supplier(models.Model):
    name = models.CharField(verbose_name="Название поставщиков")
    telephone = models.CharField(verbose_name="Телефон поставщиков")
    address = models.CharField(verbose_name="Адрес поставщиков")

    def __str__(self):
        return f'{self.name} - {self.telephone}'

    def get_absolute_url(self):
        return reverse_lazy("supplier_detail_view", kwargs={'num':self.id})

#Связь один к одному
class Doc_Toy(models.Model):
    number = models.CharField()
    date_confirm = models.DateField
    date_expire = models.DateField
    date_create = models.DateTimeField(auto_now_add=True)
    date_update = models.DateTimeField(auto_now=True)
    toy = models.OneToOneField(Toy, on_delete=models.PROTECT)

class Supply_Toys(models.Model):
    name = models.CharField()
    date_outload = models.DateTimeField(auto_now_add=True)
    toy = models.ManyToManyField(Toy)

class Order(models.Model):
    number = models.CharField(unique=True, null=True)
    date_create = models.DateTimeField(auto_now_add=True)
    address = models.CharField(blank=True)
    client_fio = models.CharField(null=True)
    client_telephone = models.CharField(null=True)
    toy = models.ManyToManyField(Toy, through='Pos_Order_Toy')

class Pos_Order_Toy(models.Model):
    toy = models.ForeignKey(Toy, on_delete=models.PROTECT)
    order = models.ForeignKey(Order, on_delete=models.PROTECT)
    count_toys = models.IntegerField(default=1)
    discount = models.DecimalField(max_digits=3, decimal_places=2, default=0.0)

class Tag(models.Model):
    name = models.CharField(max_length=30)
    description = models.CharField(max_length=180)
    toy = models.ManyToManyField(Toy)

class Category(models.Model):
    name = models.CharField(max_length=30)
    description = models.CharField(max_length=180)

    def __str__(self):
        return f'{self.name}'