from django.shortcuts import render, get_object_or_404, redirect
from django.http import HttpResponse, Http404, JsonResponse
from .forms import *
from django.views.generic import ListView, DetailView, CreateView, UpdateView, DeleteView
from .serializable import *
from rest_framework.decorators import api_view
from rest_framework.response import Response
from rest_framework import viewsets
from django.contrib.auth import login, logout
from django.contrib.auth.decorators import login_required, permission_required
from django.utils.decorators import method_decorator

# Create your views here.
def main(request):
    print(request)
    toys = Toy.objects.filter(exist=True)
    context = {"list_toys" : toys}
    return render(request, 'shop/home.html', context)

def api_start(request):
    return JsonResponse({"message" : "Hello API Django"})

@api_view(['GET'])
def api_toy(request):
    toys = Toy.objects.all()
    ser_toys = ToySerializer(toys, many=True)
    return Response({"message" : ser_toys.data})

@login_required(login_url=reverse_lazy("view_toys"))
def info(request):
    print(request.user.get_user_permissions())
    return HttpResponse(f'<h2>Info</h2>')

class ToyViewSet(viewsets.ModelViewSet):
    queryset = Toy.objects.filter(exist=True)
    serializer_class = ToySerializer

def about(request):
    print(request)
    return HttpResponse('<h3>MPT</h3>')

#shop.add_toy
#shop.view_toy
#shop.change_toy
#shop.delete_toy
@permission_required('shop.add_toy')
def calc(request, a, b):
    return HttpResponse(f'<h2>{a} + {b} = {a + b}</h2>')

def add_product(request):
    return render(request, 'shop/add_prod.html')

def change_product(request, num):
    context = {'num': num}
    return render(request, 'shop/change_prod.html', context)

def see_product(request, num):
    context = {'num': num}
    return render(request, 'shop/see_prod.html', context)

def delete_product(request, num):
    context = {'num': num}
    return render(request, 'shop/delete_prod.html', context)

def calc_get(request):
    # a = request.GET['a']
    # b = request.GET['b']
    a = request.GET.get['a']
    b = request.GET.get['b']
    return HttpResponse(f'<h2>{a} + {b} = {a + b}</h2>')

def back_connection(request):
    return render(request, 'shop/back_connection.html')

def find_by_tag(request, num):
    obj = get_object_or_404(Tag, id=num)
    toys_with_tag = obj.toy.filter(exist=True)
    context = {'tag' : obj, 'toys': toys_with_tag}
    return render(request, 'shop/find_by_tag.html', context)

def find_by_category(request, num):
    obj = get_object_or_404(Category, id=num)
    toys_with_tag = obj.toy_set.filter(exist=True)
    context = {'tag' : obj, 'toys': toys_with_tag}
    return render(request, 'shop/find_by_category.html', context)

def category_list(request):
    tags = Category.objects.all()
    context = {'tags' : tags}
    return render(request, 'shop/category_list.html', context)

def tags_list(request):
    tags = Tag.objects.all()
    context = {'tags' : tags}
    return render(request, 'shop/tag_list.html', context)

def add_category(request):
    form_supp = CategoryForm(request.POST)
    if form_supp.is_valid():
        print(form_supp.cleaned_data)
        new_supp = Category(**form_supp.cleaned_data)
        new_supp.save()

        new_supp.name = form_supp.cleaned_data.get('name'),
        new_supp.description = form_supp.cleaned_data.get('description'),
    context = {
        'form_supplier' : form_supp
    }
    return render(request, 'shop/category_create.html', context)
def add_supplier(request):
    form_em = EmailForm()
    form_supp = SupplierForm()
    if request.method == 'GET':
        print("Открытие страницы")
    elif request.method == 'POST':
        # Обработка формы Email
        # print(request.POST.get('subject'))
        # print(request.POST.get('content'))
        # #Получение данных
        # form_em = EmailForm(request.POST)
        # print(form_em.data)
        # #Проверка данных
        # form_em.is_valid()
        # print(form_em.cleaned_data)
        form_supp = SupplierForm(request.POST)
        if form_supp.is_valid():
            print(form_supp.cleaned_data)
            # new_supp = Supplier(
            #     name = form_supp.cleaned_data.get('name'),
            #     telephone = form_supp.cleaned_data.get('telephone'),
            #     address = form_supp.cleaned_data.get('address'),
            # )
            new_supp = Supplier(**form_supp.cleaned_data)
            new_supp.save()

            new_supp.name = form_supp.cleaned_data.get('name'),
            new_supp.telephone = form_supp.cleaned_data.get('telephone'),
            new_supp.address = form_supp.cleaned_data.get('address'),
    context = {
        'form_email' : form_em,
        'form_supplier' : form_supp
    }
    return render(request, 'shop/supplier_create.html', context)

class ToyList(ListView):
    model = Toy
    template_name =  'shop/home.html'
    context_object_name = 'list_toys'
    extra_context = {'title' : 'Aboba', }
    paginate_by = 1
    def get_context_data(self, *, object_list=None, **kwargs):
        context = super().get_context_data(**kwargs)
        return context
    def get_queryset(self):
        return Toy.objects.filter(exist=True)

class ToyDetail(DetailView):
    model = Toy
    pk_url_kwarg = 'num'
    template_name =  'shop/toy_detail.html'
    context_object_name = 'object'
    extra_context = {'title' : 'Aboba'}
    def get_context_data(self, *, object_list=None, **kwargs):
        context = super().get_context_data(**kwargs)
        obj = self.get_object()
        tags = obj.tag_set.all()
        context['tags'] = tags
        return context
    def get_object(self, queryset=None):
        obj = super().get_object(queryset)
        if not obj.exist:
            raise Http404("Игрушки не существует")
        return obj

class ToyCreate(CreateView):
    model = Toy
    extra_context = {"title" : "Создание игрушки", "form" : ToyForm}
    fields = ['name', 'description', 'price', 'photo', 'exist', 'supplier', 'category']
    template_name = "shop/toy_create.html"
    success_url = reverse_lazy('view_toys')

class ToyChange(UpdateView):
    model = Toy
    extra_context = {"title" : "Изменение игрушки", }
    form_class = ToyForm
    template_name = "shop/toy_create.html"
    pk_url_kwarg = 'num'
    success_url = reverse_lazy('view_toys')
    def get_object(self, queryset=None):
        obj = super().get_object(queryset)
        if not obj.exist:
            raise Http404("Игрушки не существует")
        return obj

    @method_decorator(permission_required('shop.change_toy'))
    def dispatch(self, request, *args, **kwargs):
        return super().dispatch(request, *args, **kwargs)

class ToyDelete(DeleteView):
    model = Toy
    extra_context = {"title": "Удаление игрушки", }
    template_name = "shop/toy_confirm_delete.html"
    success_url = reverse_lazy("view_toys")
    pk_url_kwarg = 'num'
    def get_object(self, queryset=None):
        obj = super().get_object(queryset)
        if not obj.exist:
            raise Http404("Игрушки не существует")
        return obj


def detail_view_toy(request, num):
    obj = get_object_or_404(Toy, id=num, exist=True)
    tags = obj.tag_set.all()
    context = {"tags" : tags, "object" : obj, "category" : obj.category}
    return render(request, 'shop/toy_detail.html', context)

class SupplierUpdate(UpdateView):
    model = Supplier
    pk_url_kwarg = 'num'
    form_class = SupplierForm()

class SupplierList(ListView):
    model = Supplier

class SupplierDetail(DetailView):
    model = Supplier
    pk_url_kwarg = 'num'

class CategoryListView(ListView):
    model = Category
    template_name = 'shop/category_list.html'
    context_object_name = 'tags'
    paginate_by = 2

class CategoryDetailView(DetailView):
    model = Category
    pk_url_kwarg = 'num'
    template_name = 'shop/category_detail.html'
    context_object_name = 'category'

class TagListView(ListView):
    model = Tag
    template_name = 'shop/tag_list.html'
    context_object_name = 'tags'
    paginate_by = 2

class TagDetailView(DetailView):
    model = Tag
    template_name = 'shop/tag_detail.html'
    context_object_name = 'tag'
    pk_url_kwarg = "num"

class TagCreateView(CreateView):
    model = Tag
    template_name = 'shop/tag_create.html'
    fields = ['name', 'description']
    success_url = reverse_lazy('tag_list_view')

class OrderListView(ListView):
    model = Order
    template_name = 'shop/order_list.html'
    context_object_name = 'orders'
    paginate_by = 2

class OrderDetailView(DetailView):
    model = Order
    template_name = 'shop/order_detail.html'
    context_object_name = 'order'
    pk_url_kwarg = "num"

class OrderCreateView(CreateView):
    model = Order
    form_class = OrderForm
    template_name = 'shop/order_create.html'
    success_url = reverse_lazy('order_list_view')

class OrderUpdateView(UpdateView):
    model = Order
    form_class = OrderForm
    template_name = 'shop/order_create.html'
    pk_url_kwarg = "num"
    success_url = reverse_lazy('order_list_view')


class OrderDeleteView(DeleteView):
    model = Order
    template_name = 'shop/order_confirm_delete.html'
    success_url = reverse_lazy('order_list_view')
    pk_url_kwarg = 'num'