from django.contrib import admin

# Register your models here.
from .models import *

class ToyAdmin(admin.ModelAdmin):
    list_display = ('id','name','price','exist')
    list_display_links = ('id',)
    list_editable = ('exist','price')
    search_fields = ('name',)
    list_filter = ('exist',)
admin.site.register(Toy)

@admin.register(Tag)
class TagAdmin(admin.ModelAdmin):
    list_display = ("name",'description')

@admin.register(Category)
class CategoryAdmin(admin.ModelAdmin):
    list_display = ("name",'description')

@admin.register(Supplier)
class SupplierAdmin(admin.ModelAdmin):
    list_display = ('pk','name','telephone','address')
    list_display_links = ('name',)
    list_editable = ('telephone','address')
    search_fields = ('name',)

@admin.register(Order)
class OrderAdmin(admin.ModelAdmin):
    pass

@admin.register(Doc_Toy)
class Doc_ToyAdmin(admin.ModelAdmin):
    pass

@admin.register(Pos_Order_Toy)
class Pos_Order_ToyAdmin(admin.ModelAdmin):
    pass

@admin.register(Supply_Toys)
class Supply_toysAdmin(admin.ModelAdmin):
    pass