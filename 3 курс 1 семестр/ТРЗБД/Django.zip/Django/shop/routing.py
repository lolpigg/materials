from django.urls import path, re_path
from shop.views import *
urlpatterns = [
    path('', main, name="catalog"),
    path('toy/view/', ToyList.as_view(), name="view_toys"),
    path('toy/detail_view/<int:num>/', ToyDetail.as_view(), name="detail_view_page"),
    path('toy/create/', ToyCreate.as_view(), name="toy_create"),
    path('toy/update_view/<int:num>/', ToyChange.as_view(), name="toy_update"),
    path('toy/add/', add_product, name="add_product"),
    path('toy/see/<int:num>/', see_product, name="see_product"),
    path('toy/change/<int:num>/', change_product, name="change_product"),
    path('toy/delete/<int:num>/', delete_product, name="delete_product"),
    path('toy/delete_view/<int:num>/', ToyDelete.as_view(), name="toy_delete_view"),
    path('supplier/create', add_supplier, name='supplier_create_page'),
    path('supplier/update/<int:num>', SupplierUpdate.as_view(), name='supplier_update_page'),
    path('supplier/view/<int:num>', SupplierDetail.as_view(), name='supplier_detail_view'),
    path('supplier/list/', SupplierList.as_view(), name='supplier_list_page'),
    path('tag/find_by_tag/<int:num>/', find_by_tag, name='find_by_tag'),
    path('tag/list/', tags_list, name='tag_list'),
    path('tag/list_view/', TagListView.as_view(), name='tag_list_view'),
    path('tag/detail_view/<int:num>/', TagDetailView.as_view(), name='tag_detail_view'),
    path('tag/create_view/', TagCreateView.as_view(), name='tag_create_view'),
    path('category/find_by_category/<int:num>/', find_by_category, name='find_by_category'),
    path('category/list/', category_list, name='category_list'),
    path('category/add/', add_category, name='add_category'),
    path('category/list_view/', CategoryListView.as_view(), name='category_list_view'),
    path('category/detail_view/<int:num>/', CategoryDetailView.as_view(), name='category_detail_view'),
    path('order/list_view/', OrderListView.as_view(), name='order_list_view'),
    path('order/detail_view/<int:num>/', OrderDetailView.as_view(), name='order_detail_view'),
    path('order/create_view/', OrderCreateView.as_view(), name='order_create_view'),
    path('order/update_view/<int:num>/', OrderUpdateView.as_view(), name='order_update_view'),
    path('order/delete_view/<int:num>/', OrderDeleteView.as_view(), name='order_delete_view'),
    path('back_connection/', back_connection, name="back_connect"),
    path('api/', api_start),
    path('calc/<int:a>/<int:b>/', calc),
    path('info/', info)
   # path('api/toys/', api_toy),
    # ^ - начало адреса
    # $ - конец адреса
    # t+ - символ t встречается 1 или более раз
    # е? - символ t встречается 1 или 0 раз
    # . - любой один символ
    # t{n} - t встречается n раз
    # t{n, m} - t встречается от n до m раз
    # \d - любая цифра
    # \D - любой символ не_цифра
    # \w - любой буквенный (буквы + цифры) символ
    # \W - любой не_буквенный (буквы + цифры) символ
]
from rest_framework import routers
router = routers.DefaultRouter()
router.register(r"api/toys", ToyViewSet, basename='Toys')
urlpatterns += router.urls